---
name: ms-frontend-code-review
description: |
  面向 D:\work\km-mom-next-web 的前端代码审查 skill，覆盖管理端 apps/km-mom-web、工作台 apps/km-mom-dashboard-web 以及必要时的 packages/components。Use when: frontend code review、PR review、reviewing changed React/Umi/Ant Design/TypeScript/Less code、审查管理端或工作台页面、弹框、任务卡、首页初始化请求、公共组件改动、ESLint/Prettier/test 验证风险。
---

# MS 前端代码审查

## 核心定位

把审查重点放在缺陷、回归风险、项目规则违背、验证缺口和可维护性问题上。不要把 code review 变成个人偏好重写，也不要重复指出 Prettier、import 排序这类可由工具处理的问题。

审查 `km-mom-next-web` 时，先读取命中路径的项目规则；需要项目配置细节时读取 [KMMOM 前端审查参考](references/kmmom-frontend-review.md)。

## 适用范围与不做清单

适用范围：

- 审查 `D:\work\km-mom-next-web` 中管理端 `apps/km-mom-web` 的前端改动。
- 审查 `D:\work\km-mom-next-web` 中工作台 `apps/km-mom-dashboard-web` 的前端改动。
- 审查与上述应用直接相关的 `packages/components` 公共组件改动。
- 审查 React、Umi、Ant Design、TypeScript、Less、CSS Modules、测试落点、验证命令和项目规则执行风险。

不做清单：

- 不用于后端、数据库、接口契约或部署脚本的完整审查。
- 不用于其他前端仓库的通用代码审查，除非用户明确要求借鉴本 skill 的审查框架。
- 不替代仓库实时 `AGENTS.md`、`docs/project-rules/*.md`、`package.json` 和 ESLint 配置。
- 不负责直接修改被审查代码；默认只输出审查发现、风险、待确认项和建议验证。
- 不替代 `$delivery-review`，交付前仍应按 Coding 任务要求执行交付审查。

## 审查前置动作

1. 确认变更范围：读取 diff、用户需求、关联 issue/PR 描述和改动文件路径。
2. 读取规则入口：先读根 `AGENTS.md`，再按路径读取 `apps/km-mom-web/AGENTS.md`、`apps/km-mom-dashboard-web/AGENTS.md` 或 `packages/components/AGENTS.md`。
3. 读取项目通用规则：至少关注 `docs/project-rules/workflow.md`、`frontend.md`、`structure.md`、`testing.md`、`comments.md`。
4. 读取质量配置：查看根 `.eslintrc.js`、命中 workspace 的 `.eslintrc.js`、`package.json` scripts，必要时查看 `.prettierrc.js`。
5. 确认验证状态：区分已执行的命令、未执行但应执行的命令、因环境限制无法执行的命令。

## 审查优先级

### 1. 正确性与回归风险

- 检查业务分支、空值、异常响应、权限、路由上下文、组织编码、缓存键、异步回填后的编辑态。
- 检查 `useEffect`、`useMemo`、`useCallback` 是否因为依赖不当造成重复请求、旧闭包、初始化链路重入。
- 检查接口调用是否读取了刚 `setState` 后的旧 state；初始化链路应优先使用接口返回值、局部变量、显式入参或 `ref`。
- 检查同一接口的完整口径和降级口径是否互斥，只允许在单一决策点发起真实请求。
- 检查共享组件数据源回调是否稳定，避免 render 期间内联函数导致重复加载。

### 2. 项目边界与目录结构

- 管理端页面入口 `index.tsx` 应主要负责页面级编排；复杂弹框、schema、选择器、成组接口逻辑不要堆进入口文件。
- 工作台任务卡类页面优先评估是否沿用 `src/components/KObjectTaskCardWrapper`。
- 页面私有组件默认放在页面目录下 `components/`；弹框、抽屉默认放在页面目录下 `modal/`。
- 单点逻辑优先就地收拢；不要为了“更清晰”把一次性常量、转换、校验、权限判断抽成独立 `hook`、`utils` 或公共方法。
- 非必要不要修改 `packages/`；如果审查发现公共包改动，重点检查调用方范围、导出边界、向后兼容和是否已有用户确认。

### 3. 复用与组件选择

- 优先使用 `packages/components` 中已有组件，其次使用 Ant Design，再考虑业务侧自定义组件。
- 不接受只包一层 `requestApi` 的伪复用；只有跨页面、跨模块、跨业务域稳定复用时，才沉淀到 `service`、`src/utils` 或公共包。
- 公共组件 `index.ts` 只导出组件和必要公开类型，不导出内部 `utils`、调试常量、测试辅助函数或实现细节。

### 4. ESLint、Prettier 与人工补审

- 管理端 `apps/km-mom-web` 显式关闭 `unused-imports/no-unused-imports`、`unused-imports/no-unused-vars`、`@typescript-eslint/no-unused-vars`，根配置也关闭这些规则；审查管理端时必须人工检查未使用 import、未使用变量、死代码和调试残留。
- 工作台 `apps/km-mom-dashboard-web` 继承 `@umijs/lint`，局部配置未显式关闭 unused 规则；仍需结合 diff 判断工具未覆盖的死分支和无效状态。
- 不把格式、分号、引号、import 排序作为阻塞意见；这些交给 `lint`、`prettier` 和项目配置。
- 对 `*.less` 重点检查 CSS Modules 约定：类名用小写短横线，单类使用 `styles['xxx-xxx']`，多类使用 `classNames`。

### 5. 测试与验证

- 新增测试不要放在业务 `src/` 同级；按 workspace 镜像到 `tests/src/` 或放到 `tests/features/`。
- 管理端单测优先运行 `pnpm --filter km-mom-web test -- tests/src/<path>/<file>.test.tsx`。
- 工作台单测优先运行 `pnpm --filter km-mom-dashboard-web test -- tests/src/<path>/<file>.test.tsx`。
- 局部 lint 优先运行 `pnpm --filter km-mom-web lint` 或 `pnpm --filter km-mom-dashboard-web lint`。
- 类型检查优先运行命中 workspace 的 `pnpm --filter <workspace> tsc`；涉及公共包时再考虑对应包的 `type-check` 或 `build`。
- 构建只在改动触及构建配置、跨 workspace 依赖、公共导出、编译敏感代码或用户明确要求时建议执行。

## 反馈写法

审查结论必须先列问题，按严重程度排序。每条问题包含路径、行号、事实依据、影响和可执行修正建议。

使用这些标签：

- `[blocking]`：合并前必须修复，会导致功能错误、明显回归、安全风险或规则硬违背。
- `[important]`：应该修复；如果作者不同意，需要给出技术依据。
- `[nit]`：非阻塞小问题，只在确实提升可读性或一致性时提出。
- `[suggestion]`：备选方案，不作为强制要求。
- `[question]`：信息不足，需要作者确认，不要伪装成确定缺陷。
- `[praise]`：只在确实有值得保留的设计时使用，保持克制。

示例：

```markdown
[blocking] apps/km-mom-dashboard-web/src/pages/Workbench/index.tsx:86
这里先 `setOrgCode(nextOrgCode)`，随后仍用闭包中的 `orgCode` 决定请求分支。冷启动时会读取旧值，导致已拿到组织编码仍请求默认配置。建议改为基于 `nextOrgCode` 或显式入参做互斥分支。
```

## 输出格式

```markdown
## 问题列表

- [blocking] path/to/file.tsx:行号 - 问题标题
  事实、影响、建议修正。

## 待确认

- 需要作者确认的问题；没有则写“无”。

## 验证

- 已看到的验证：命令与结果。
- 建议补充的验证：命令与原因。

## 摘要

简要说明本次改动意图和总体风险，不要替代上面的问题列表。
```

如果没有发现问题，明确写“未发现阻塞或重要问题”，再说明仍存在的测试缺口或未验证范围。
