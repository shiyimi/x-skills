# KMMOM 前端审查参考

## 快照说明

本文件仅作为审查导航和当前配置快照。实际审查时必须以 `D:\work\km-mom-next-web` 仓库中的实时 `AGENTS.md`、`docs/project-rules/*.md`、`package.json`、`.eslintrc.js` 和命中 workspace 配置为准；如果本文件与仓库实时文件冲突，以仓库实时文件为准。

## 目录

- [快照说明](#快照说明)
- [事实来源](#事实来源)
- [技术栈与工作区](#技术栈与工作区)
- [ESLint 与 Prettier 快照](#eslint-与-prettier-快照)
- [命令参考](#命令参考)
- [管理端重点规则](#管理端重点规则)
- [工作台重点规则](#工作台重点规则)
- [通用前端审查清单](#通用前端审查清单)

## 事实来源

本参考基于以下本地文件整理：

- `D:\work\km-mom-next-web\AGENTS.md`
- `D:\work\km-mom-next-web\docs\project-rules\workflow.md`
- `D:\work\km-mom-next-web\docs\project-rules\frontend.md`
- `D:\work\km-mom-next-web\docs\project-rules\structure.md`
- `D:\work\km-mom-next-web\docs\project-rules\testing.md`
- `D:\work\km-mom-next-web\docs\project-rules\comments.md`
- `D:\work\km-mom-next-web\apps\km-mom-web\AGENTS.md`
- `D:\work\km-mom-next-web\apps\km-mom-dashboard-web\AGENTS.md`
- `D:\work\km-mom-next-web\packages\components\AGENTS.md`
- `D:\work\km-mom-next-web\.eslintrc.js`
- `D:\work\km-mom-next-web\apps\km-mom-web\.eslintrc.js`
- `D:\work\km-mom-next-web\apps\km-mom-dashboard-web\.eslintrc.js`
- `D:\work\km-mom-next-web\package.json`
- `D:\work\km-mom-next-web\apps\km-mom-web\package.json`
- `D:\work\km-mom-next-web\apps\km-mom-dashboard-web\package.json`

## 技术栈与工作区

- Monorepo 使用 `pnpm`，不要切换到 `npm` 或 `yarn`。
- 管理端 workspace：`km-mom-web`，路径 `apps/km-mom-web`。
- 工作台 workspace：`km-mom-dashboard-web`，路径 `apps/km-mom-dashboard-web`。
- 前端主要技术栈：React 18、Umi Max、Ant Design 5、TypeScript、Less、CSS Modules。
- 常用共享包包括 `@km-dev-ui/components`、`@km-dev-ui/km-web`、`@km-dev-ui/table-engine`、`@km-dev-ui/utils`。

## ESLint 与 Prettier 快照

根 `.eslintrc.js`：

- `extends: [require.resolve('@umijs/lint/dist/config/eslint')]`
- `globals: { page: true, REACT_APP_ENV: true }`
- 关闭 `unused-imports/no-unused-imports`
- 关闭 `unused-imports/no-unused-vars`
- 关闭 `@typescript-eslint/no-unused-vars`

管理端 `.eslintrc.js`：

- 同样继承 `@umijs/lint/dist/config/eslint`
- 同样声明 `page`、`REACT_APP_ENV`
- 同样关闭 unused import 和 unused vars 相关规则

工作台 `.eslintrc.js`：

- 继承 `@umijs/lint/dist/config/eslint`
- 声明 `page`、`REACT_APP_ENV`
- 未显式关闭 unused import 和 unused vars 相关规则

根 `.prettierrc.js`：

- `singleQuote: true`
- `trailingComma: 'all'`
- `printWidth: 100`
- `endOfLine: 'lf'`
- 插件包含 `prettier-plugin-organize-imports`、`prettier-plugin-packagejson`、`prettier-plugin-two-style-order`

## 命令参考

优先只运行命中 workspace 的命令：

```bash
pnpm --filter km-mom-web lint
pnpm --filter km-mom-web tsc
pnpm --filter km-mom-web test -- tests/src/<relative-path>/<file>.test.tsx
pnpm --filter km-mom-web build:test

pnpm --filter km-mom-dashboard-web lint
pnpm --filter km-mom-dashboard-web tsc
pnpm --filter km-mom-dashboard-web test -- tests/src/<relative-path>/<file>.test.tsx
pnpm --filter km-mom-dashboard-web build:test
```

涉及公共组件包时，按实际 package scripts 选择：

```bash
pnpm --filter @km-dev-ui/components type-check
pnpm --filter @km-dev-ui/components build
```

不要在局部改动场景下默认建议全量 `pnpm lint`、`pnpm test`、`pnpm build`。

## 管理端重点规则

- 页面入口 `index.tsx` 负责路由上下文、页面级 `ref`、弹框显隐、列表刷新、页面按钮和页面组件装配。
- 复杂弹框内部表单逻辑、明细表 schema、页面私有通用选择器、成组接口封装不要堆在页面入口。
- 新增页面组件优先使用 `components/A/A.tsx` 目录式模块，并配套 `index.ts`、`index.less`、`interface.ts`。
- 简单弹框可以保留 `XxxModal.tsx` 单文件；同时包含请求、表格 schema、校验规则、较重状态编排时，再升级为独立目录。

## 工作台重点规则

- 如果当前页面已有稳定模式，优先延续同页面或同业务域做法。
- 任务卡类页面优先评估沿用 `src/components/KObjectTaskCardWrapper`。
- 工作台首页 AI 分析后的“推荐动作”默认仅展示，不响应点击、确认、执行、请求回写或跳转。
- 工作台首页“待办”“工作”默认不提供点击跳转能力。
- 初始化链路里，前一步刚写入 state，后一步不得读取旧 state 做请求分支；应使用返回值、局部变量、显式入参或 `ref`。
- 同一接口存在完整口径和降级口径时，先在单一决策点确定互斥策略，再发起真实请求。

## 通用前端审查清单

- 请求编排：是否存在页面、组件、model、layout、runtime 同时发起同口径请求。
- 回调稳定性：传给共享组件的 `source`、`loadOptions`、`schemaResolver`、`customDataFetch` 是否稳定。
- 缓存键：短时缓存是否包含用户、页面、业务口径、路由上下文等关键条件。
- 表格编辑：异步回填或刷新后，行内编辑是否用函数式 `setState` 按 `rowId` 局部 patch。
- 测试落点：新增测试是否位于当前 workspace 的 `tests/src/` 或 `tests/features/`。
- 注释：`interface.ts` 中 `interface`、`type`、`enum` 及字段是否有中文业务注释；具名业务函数是否有中文注释。
- 样式：新增 Less 类名是否为小写短横线，TSX 是否通过 CSS Modules 引用。
- 公共包：`packages/components` 的 `index.ts` 是否只导出组件和必要公开类型。
